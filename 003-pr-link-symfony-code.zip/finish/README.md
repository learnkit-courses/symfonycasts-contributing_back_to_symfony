# Contributing back to Symfony!

Well hi there! This repository holds the code and script
for the [Contributing back to Symfony!](https://knpuniversity.com/screencast/contributing) course on KnpUniversity.

## Have Ideas, Feedback or an Issue?

If you have suggestions or questions, please feel free to
open an issue on this repository or comment on the course
itself. We're watching both :).

## Thanks!

And as always, thanks so much for your support and letting
us do what we love!

<3 Your friends at KnpUniversity
