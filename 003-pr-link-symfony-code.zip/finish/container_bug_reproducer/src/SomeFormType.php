<?php

namespace App;

use Symfony\Component\Form\AbstractType;

class SomeFormType extends AbstractType
{

}
